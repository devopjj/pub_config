function geoip() {
  local ip="$1"
  local mmdb="/usr/share/GeoIP/GeoLite2-City.mmdb"
  #local mmdb="/home/jim/env.j/src/db/DBIP-City.mmdb"

  # 參數驗證
  if [[ -z "$ip" ]]; then
    echo "錯誤: 請提供IP地址" >&2
    return 1
  fi

  if [[ ! -f "$mmdb" ]]; then
      echo "错误: GeoIP数据库文件不存在: $mmdb" >&2
      return 1
  fi

   # 查询 mmdb
  local output
  output=$(mmdblookup --file "$mmdb" --ip "$ip" 2>/dev/null)
  if [[ -z "$output" ]]; then
      echo "错误: IP $ip 无相关数据" >&2
      return 1
  fi


  # 用awk统一提取中文名称
  local geo_info
  geo_info=$(echo "$output" | awk '
    BEGIN { 
      continent = "N/A"; country = "N/A"; subdivisions = "N/A"; city = "N/A"; section = ""
    }
    /"continent":/ { section = "continent"; next }
    /"country":/ { section = "country"; next }
    /"subdivisions":/ { section = "subdivisions"; next }
    /"city":/ { section = "city"; next }
    /"location":/ || /"registered_country":/ { section = ""; next }
    # 捕获 zh-CN 字段
    section != "" && /"zh-CN":/ {
      # 读取下一行取得具体名称
      getline
      gsub(/"/, "")
      gsub(/<utf8_string>/, "")
      gsub(/^[ \t]+|[ \t]+$/, "")
      if (section == "continent") continent = $0
      else if (section == "country") country = $0
      else if (section == "subdivisions") subdivisions = $0
      else if (section == "city") city = $0
    }
    END {
      print continent "|" country "|" subdivisions "|" city
    }
  ')
  
  # 解析结果
  IFS='|' read -r continent country subdivisions city <<< "$geo_info"

  # 输出格式化结果
  printf "IP: %s\n洲: %s\n国家: %s\n省份: %s\n城市: %s\n" "$ip" "$continent" "$country" "$subdivisions" "$city"
}