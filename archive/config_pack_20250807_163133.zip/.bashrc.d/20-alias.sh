# ~/.bashrc.d/20-alias.sh

alias lx='ls -lXB'         #  Sort by extension.
alias lk='ls -lSr'         #  Sort by size, biggest last.
alias lt='ls -ltra'         #  Sort by date, most recent last.
alias lc='ls -ltcr'        #  Sort by/show change time,most recent last.
alias lu='ls -ltur'        #  Sort by/show access time,most recent last.
alias vi='vim'
##alias ll='ls -alFh ' 2>/dev/null
# The ubiquitous 'll': directories first, with alphanumeric sorting:
#0911 alias ll="ls -lav --group-directories-first"
alias ll="ls -lav "
alias lm='ll |more'        #  Pipe through 'more'
alias lr='ll -R'           #  Recursive ls.
alias la='ll -A'           #  Show hidden files.
alias l='ls -CF'
alias l.='ls -d .*' 2>/dev/null
alias tree='tree -C -L 1'
alias tree2='tree -ACsuh'    #  Nice alternative to 'recursive ls' ...
alias rm='rm -i'
alias cp='cp -i'
alias mv='mv -i'
# -> Prevents accidentally clobbering files.
alias mkdir='mkdir -p'

alias h='history'
##alias j='jobs -l'
alias ..='cd ..'

alias du='du -kh'    # Makes a more readable output.
alias dus='du -hs * |sort -h'
alias df='df -kTh'
alias less="less -r"

alias gt='sudo /data/htdocs/m.srv4u.info/_cron_17sing/getToken.sh'
alias wp='s=`which python`;cd ${s%%venv/*}'
alias penv='source venv/bin/activate'
alias mcurl='curl -H "User-Agent: Mozilla/5.0 (iPhone; CPU iPhone OS 14_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0.3 Mobile/15E148 Safari/604.1" \
     -H "Accept: text;q=0.9,*/*;q=0.8" \
     -H "Accept-Language: en-US,en;q=0.9" \
     -H "Connection: keep-alive" \
     -H "Upgrade-Insecure-Requests: 1"'
     

alias myip="curl -sq https://ifconfig.io"
alias wgets='H="--header"; wget --no-check-certificate $H="Accept-Language: en-us,en;q=0.5" $H="Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8" $H="Connection: keep-alive" -U "Mozilla/5.0 (Windows NT 5.1; rv:10.0.2) Gecko/20100101 Firefox/10.0.2" --referer=/ '
alias gitlog=' git log --oneline && git log -p -1 --stat'
alias gitpull='git pull &&  git --no-pager log --name-status -1'

alias ap='ansible-playbook'
alias dnsreload='ssh 10.11.11.110 "sudo systemctl restart dnsmasq"'
alias clashreload='ssh -p 22 -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null 10.11.11.23 "sudo systemctl restart clash"'
alias mosdnsreload='ssh -p 22 -o StrictHostKeyChecking=no  10.11.11.110 "sudo systemctl restart mosdns"'


alias imac='ssh ericlin@10.11.11.109'
alias proxyeric='ssh -ND 8888 ericlin@10.11.11.109'
alias proxyeric2='ssh -ND 8888 -p 8822 eric@10.11.11.25'

alias gdcopy='rclone -P --config=/home/jim/.config/rclone/rclone-gd.conf copy $@'
alias gdlsd='rclone -P --config=/home/jim/.config/rclone/rclone-gd.conf lsd $@'
alias tf="$(which terraform)"
alias countmp4="ls -al | grep -E '(.mp4|^d)' | awk '{print $9}' | grep -vE '\.$|\.\.$'|wc -l"
#alias countmp4='find . -maxdepth 1 -type f -name "*.mp4" -o -type d ! -name "." ! -name ".." | wc -l'
alias alert='notify-send --urgency=low -i "$([ $? = 0 ] && echo terminal || echo error)" "$(history|tail -n1|sed -e '\''s/^\s*[0-9]\+\s*//;s/[;&|]\s*alert$//'\'')"'
