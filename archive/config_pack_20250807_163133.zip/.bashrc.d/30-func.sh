# =========================================================
# host: JJ.ME
# service: bash/zsh
# filename: # ~/.bashrc.d/30-func.sh
# filedesc: Common RC file
# update: 2025-06-27 , 09:39
# =========================================================

# 打开
function proxy_on() {
	export no_proxy="localhost,127.0.0.1,localaddress,.localdomain.com"
	export http_proxy="http://tcproxy.seed.net.tw:8080/"
	export https_proxy=$http_proxy
	echo -e "已开启代理"
}

# 关闭
function proxy_off(){
	unset http_proxy
	unset https_proxy
	echo -e "已关闭代理"
}

function zip_clean() {
  local name=${1:-"code.zip"}
  find . -type f \
    ! -path "*/.git/*" \
    ! -path "*/venv/*" \
    ! -path "*/.venv/*" \
    ! -path "*/__pycache__/*" \
    -print | zip ${name}.zip -@
}

#-------------------------------------------------------------
# File & strings related functions:
#-------------------------------------------------------------
function extract()      # Handy Extract Program
{
    if [ -f $1 ] ; then
        case $1 in
            *.tar.bz2)   tar xvjf $1     ;;
            *.tar.gz)    tar xvzf $1     ;;
            *.bz2)       bunzip2 $1      ;;
            *.rar)       unrar x $1      ;;
            *.gz)        gunzip $1       ;;
            *.tar)       tar xvf $1      ;;
            *.tbz2)      tar xvjf $1     ;;
            *.tgz)       tar xvzf $1     ;;
            *.zip)       unzip $1        ;;
            *.Z)         uncompress $1   ;;
            *.7z)        7z x $1         ;;
            *)           echo "'$1' cannot be extracted via >extract<" ;;
        esac
    else
        echo "'$1' is not a valid file!"
    fi
}
# Creates an archive (*.tar.gz) from given directory.
function maketar() { tar cvzf "${1%%/}.tar.gz"  "${1%%/}/"; }

# Create a ZIP archive of a file or folder.
function makezip() { zip -r "${1%%/}.zip" "$1" ; }


function my_ip(){ # Get IP adress on ethernet.

    MY_IP=$(/sbin/ifconfig eth0 | awk '/inet/ { print $2 } ' |
      sed -e s/addr://)
    echo ${MY_IP:-"Not connected"}
}

# Add an "alert" alias for long running commands.  Use like so:
#   sleep 10; alert
alias alert='notify-send --urgency=low -i "$([ $? = 0 ] && echo terminal || echo error)" "$(history|tail -n1|sed -e '\''s/^\s*[0-9]\+\s*//;s/[;&|]\s*alert$//'\'')"'

function sendslack() {
  # SmartJJ@smartjj 
  slack_jim="https://hooks.slack.com/services/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"
  # SIT999@notify
  slack_notify="https://hooks.slack.com/services/TNJ93CSFL/BU2RKM0CU/1O9VvsuwSnDfXPhqBDNlb2h"
  # SIT999@Eric
  slack_eric="https://hooks.slack.com/services/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"
  if [ -z "$2" ]; then
      echo "Usage: $0 [jim|nms] [text_to_send]";
      return 1;
  fi
  webhook_name=`echo $1|tr '[:upper:]' '[:lower:]'`
#echo $webhook_name
  if [  "$webhook_name" = "jim" ];then 
    slack_hookurl=$slack_jim
  elif [   "$webhook_name" = "nms" ];then 
    slack_hookurl=$slack_notify
  else
    slack_hookurl=$slack_eric
  fi

  slack_text="$2"
  curl -o /dev/null -s -X POST --header 'cache-control: no-cache' \
  --data-urlencode 'payload={"mrkdwn": true, "icon_emoji": ":thumbsup_all:", "username": "JJ-Bot","text":"'"$slack_text"'"}'   \
  $slack_hookurl > /dev/null
}

function sendtg2(){
  if [ -z "$1" ]; then
      echo "Usage: sendtg [text_to_send]";
      return 1;
  fi
  
  # A00.JJ_Info
  chat_a00_JJ_Info="-1002061622893"
  jj01bot_token="1124675180:AAHXnQ03W_2B_lIcR2FRe4DrUopyXaXShYE"
  telegram_url="https://api.telegram.org/bot$jj01bot_token/sendMessage"
  tg_text="$1\n -- $GHOST"

  curl -q -s -X POST \
  -H 'Content-Type: application/json' \
  -d '{"chat_id": '"$chat_a00_JJ_Info"', "text": "'"$tg_text"'", "parse_mode": "Markdown", "disable_notification": true}' \
  $telegram_url >/dev/null
}

function tmd(){
  session_name="douyin-loop"
  if  tmux has-session -t $session_name 2>/dev/null; then
    # attach 到刚创建的 tmux session
    tmux attach -t $session_name

  else
    # 创建一个名为 $session_name 的新 tmux 会话
    tmux new-session -d -s $session_name
    # 确保会话已初始化完成
    sleep 1  # 可以根据需要调整延迟时间

    # 将视窗分割为4个
    #tmux split-window -t $session_name:0.0 -h
    tmux split-window -t $session_name:0.0 -v
    #tmux split-window -t $session_name:0.2 -v

    # 在每个视窗执行指令


    # 选择左下角视窗并执行指令
    tmux send-keys -t $session_name:0.0 'cd ;pwd' Enter
    # 选择左上角视窗并执行指令
    tmux send-keys -t $session_name:0.1 'cd /data/home/gitrepo/getDouYin;penv;' Enter
    # 选择右上角视窗并执行指令
    #tmux send-keys -t $session_name:0.2 'cd /data/home/gitrepo/notebook/; ./startnb.sh' C-m
    # 选择右下角视窗并执行指令
    #tmux send-keys -t $session_name:0.3 'w && pwd' C-m

    # 返回第一个视窗
    ##tmux select-pane -t $session_name:0.0
  fi
}

function purge_git_repo(){
  set -e  # 当有命令失败时，立即退出
  [[ ! -d ".git" ]] && echo ".git not found" && exit 1
  old_git_size=$(du -sh .git/)

  echo "${BYellow}1.创建一个没有历史记录的新分${NC}"
  git checkout --orphan latest_branch

  echo "${BYellow}1-2.添加所有文件${NC}"
  git add -A

  echo "${BYellow}1-3.提交更改:删除历史版本记录，初始化仓库${NC}"
  git commit -am "删除历史版本记录，初始化仓库"

  echo "${BYellow}1-4.删除 master 分支${NC}"
  git branch -D master

  echo "${BYellow}1-5.将 latest_branch 分支重命名为 master${NC}"
  git branch -m master


  echo "${BYellow}1-6.将修改推送到远程仓库${NC}"
  remote_repo=$(grep "\[remote" .git/config | cut -d "\"" -f2)
  git push -f ${remote_repo} master

  # 手动运行垃圾回收
  echo "${BYellow}2-1.执行垃圾回收${NC}"
  git gc --prune=now --aggressive

  echo "${BYellow}2-2.删除所有未追踪的文件和目录${NC}"
  git clean -fd

  echo "${BYellow}2-3.删除所有远程追踪的分支引用${NC}"
  git branch -r | xargs -L1 git branch -rD

  echo "${BYellow}2-4.删除旧的 reflogs${NC}"
  git reflog expire --expire=now --all

  echo "${BYellow}2-5.检查 .git 目录的内容${NC}"
  new_git_size=$(du -sh .git/)
  echo "${BYellow}${old_git_size} -> ${new_git_size}${NC}"

  echo "${BYellow}2-6.设定 origin ${NC}"
  git fetch origin
}


function dlmp3() {
    local video_id="$1"
    local convert_mp3="$2"
    local output_dir="/share1/dl_youtube"
    
    if [[ -z "$video_id" ]]; then
        echo "Usage: download_youtube_audio <video_id>"
        return 1
    fi

    local args=()
    args+=()
    if [[ "$convert_mp3" == "best" ]]; then
        args+=("--audio-format best")
    else
        args+=("--audio-format mp3")
    fi

    echo yt-dlp --cookies $output_dir/www.youtube.com_cookies.txt \
           --extract-audio $args  $video_id \
           -o "'$output_dir/yt_mp3/%(title)s.%(ext)s'"

}


function xkill(){
  ps -ef|grep $1|grep -v 'grep'| awk '{print $2}'| xargs kill -9
  echo "kill process about $1"
  }

function exractmp4(){
  [[ -z $1 ]] && echo "must webm source file" && return 1
  local outfile=$(echo $1|sed -e "s/webm/m4a/g")
  ffmpeg -i "$1" -vn -c:a aac -b:a 192k -y "$outfile" >/dev/null 2>&1

  }

function greppy(){
  [[ -z $1 ]] && echo "must input keyword" && return 1

  grep -ril "$1" --include="*.py" --exclude-dir={venv,.venv,env,.env}

}

function starthugo(){
  [[ -z $1 ]] && echo "must input site_name" && return 1
  /data/home/gitrepo/md2blog/start_server.sh server $1
  echo "start hugo server(dev): $1"
}


function cleanhugo(){
  [[ -z $1 ]] && echo "must input site_name" && return 1
  /data/home/gitrepo/md2blog/start_server.sh cleancache $1
  echo "cleancache hugo server(dev): $1"
}

function dephugo(){
  [[ -z $1 ]] && echo "must input site_name" && return 1
  /data/home/gitrepo/md2blog/start_server.sh  deploy $1
  if [ "$?" == "0" ];then
    echo "deploy successfully : $1"
  else
    echo "deploy failed : $1"
  fi
}

function monitor_live(){
  tail -f  /share1/log/douyin_live_recorder_out.log |sed 's/\x1b\[[0-9;]*m//g'
}


# tail 为日志着色
function tailcc(){
  if [ -z "$1" ]; then
    echo "Usage: tailcc <file>"
    return
  fi

  # 使用 tail -f 和 ccze 组合
  tail -f "$1" | ccze -A
}
# 将gitea搬移到 AwsCC
function movetoAwsRepo(){
  [[ -z $1 ]] && echo "must input repo name" && return 1


REPO="$1"
cd "/data/home/gitrepo/$REPO"

awsRegion="ap-east-1"
gitUrl=$(aws codecommit create-repository --repository-name $REPO --region $awsRegion | grep cloneUrlSsh|cut -d "\"" -f4)
git remote set-url origin $gitUrl
git add .
git commit --allow-empty -m "${DATESN} 由 gitea 转到 Aws"
git push --set-upstream origin master
echo aws codecommit update-repository-description --repository-name $REPO --repository-description "Your repository description" --region $awsRegion
}

# 将目录下全部视频转为m4a
function convertm4a(){
  [ ! -z "$1" ] && restriction="-maxdepth $1" || restriction=""
  bitrate="192k"
  echo "Converting bitrate: $bitrate"
  log="./conver_${bitrate}.log"
  true > $log

  #ls | grep -vE "\.m4a$|\.mp3$|\.sh$" | while read -r w; do
  #find ./ $restriction -type f ! -name "*.m4a" ! -name "*.mp3" ! -name "*.sh"| while read -r w; do
  find ./ $restriction -type f \( \
  -iname "*.mp4" \
  -o -iname "*.mkv" \
  -o -iname "*.avi" \
  -o -iname "*.mov" \
  -o -iname "*.wmv" \
  -o -iname "*.flv" \
  -o -iname "*.webm" \) | while read -r w; do

    # 提取文件名，不包括路径和扩展名
    name=${w%.*}
    base_name=$(echo "$name"|  tr -d ' ' |sed -e "s/#/_/g")
    echo "convertin $base_name"
    # 生成新的 mp3 文件名
    mp3_file="${base_name}.mp3"

    # 生成新的 m4a 文件名
    m4a_file="${base_name}.m4a"

    # 执行 ffmpeg 转换操作
    #ffmpeg -i "$w" -vn -ab 320k -ar 48000 -y "$mp3_file"
    # 执行 ffmpeg 转换操作，设置音频质量为 128k
    echo ffmpeg -i "$w" -vn -c:a aac -b:a "$bitrate" -y "$m4a_file"
    ffmpeg -i "$w" -vn -c:a aac -b:a "$bitrate" -y "$m4a_file" >/dev/null 2>&1
    #ffmpeg -i "$w" -vn -q:a 2 -y "$mp3_file"
    if [ $? -eq 0 ]; then
        echo "Conversion successful: ${m4a_file}"|tee -a $log
        gzip "$w"
    else
        echo "Conversion failed: ${m4a_file}"|tee -a $log
    fi
  done
}

function showgrab(){
cat /share1/log/pve{1,2}_71_monitor_grab.log | grep "✅" | awk '{
    task=$5
    host=$9
    seconds=$7
    tasks[task] = tasks[task] " " host " ("seconds")"
} END {
    for (t in tasks) {
        print  t " ：" tasks[t]
    }
}'
}

function clear_live_upload(){
find /mnt/new_mypool2/douyin_downloads/DouyinLiveRecorder/抖音直播/ready-upload/2* \
-mindepth 1 -maxdepth 1 -type f \( -name "*.ts" -o -name "*.mp4" \) -delete
}  

function monitor_url(){
  while true; do
    echo "=== CURL 測速工具 ==="
    echo "測試網站: $1"

    result=$(curl -m 10 --connect-timeout 5 -s -o /dev/null -w "%{time_namelookup} %{time_connect} %{time_appconnect} %{time_pretransfer} %{time_starttransfer} %{time_total} %{size_download} %{speed_download}" "$1")

    # 分解結果
    read dns tcp ssl pre start total size speed <<< "$result"

    avg_speed_kb=$(awk "BEGIN {printf \"%.2f\", $speed / 1024}")

    echo "=============================="
    echo "DNS 查找時間: $dns s"
    echo "TCP 連接時間: $tcp s"
    echo "SSL 握手時間: $ssl s"
    echo "開始傳輸時間: $pre s"
    echo "首字節時間: $start s"
    echo "=============================="
    echo "總時間: $total s"
    echo "下載大小: $size bytes"
    echo "下載速度: $speed bytes/sec"
    echo "平均速度: $avg_speed_kb KB/s"
    echo "=============================="

    sleep 60
  done
}




# 自动 help 输出
show_help() {
dir=$(dirname "$(readlink -f "${BASH_SOURCE[0]}")")

echo "Scanning directory: $dir"
echo

for file in "$dir"/*.sh; do
    [[ -e "$file" ]] || { echo "No .sh files found in $dir"; exit 1; }
    echo "File: $(basename "$file")"

    awk '
    BEGIN { desc="" }
    /^[[:space:]]*#/ { desc = $0; next }
    /^[[:space:]]*(function[[:space:]]+)?[a-zA-Z0-9_]+[[:space:]]*\(\)[[:space:]]*\{/ {
        line = $0
        gsub(/function[[:space:]]+/, "", line)
        gsub(/[[:space:]]*\(\)[[:space:]]*\{/, "", line)
        gsub(/^[[:space:]]+|[[:space:]]+$/, "", line)
        gsub(/^[[:space:]]*# ?/, "", desc)
        printf "  %-20s - %s\n", line, desc
        desc=""
    }
    ' "$file"

    echo
done
}

