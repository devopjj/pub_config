#!/bin/bash

# 人类可读速度转换
human_speed() {
    local speed=${1%.*}  # 去除小數點後
    if [[ $speed -lt 1024 ]]; then
        echo "${speed} B/s"
    elif [[ $speed -lt 1048576 ]]; then
        printf "%.2f KB/s\n" "$(echo "$1 / 1024" | bc -l)"
    else
        printf "%.2f MB/s\n" "$(echo "$1 / 1048576" | bc -l)"
    fi
}


# 检查本地证证书：privkey.pem, fullchain.pem
function sslchk() {
  keyfile="privkey.pem"
  crtfile="fullchain.pem"

  echo "Check SSL Date" && openssl x509 -in $crtfile -noout -text|grep After && \
  echo "Check SSL Common Name" && openssl x509 -in $crtfile -noout -text|grep -E "DNS|CN" 

  # check key tpye: RSA/RC
  grep -q "BEGIN EC PRIVATE KEY" $keyfile
  if [ "$?" == "0" ];then
    echo "key_type: EC"
    # EC-256
    md5_cert=$(openssl x509 -pubkey -in $crtfile -noout|openssl md5|awk '{print $2}')
    md5_key=$(openssl pkey -pubout -in  $keyfile | openssl md5|awk '{print $2}')
  else
  # RSA
    echo "key_type: RSA"
    md5_cert=$(openssl x509 -noout -modulus -in $crtfile|openssl md5|awk '{print $2}') 
    md5_key=$(openssl rsa -noout -modulus -in $keyfile|openssl md5|awk '{print $2}')
  fi
  printf "%-10s %s\n" "md5_cert " "$md5_cert"
  printf "%-10s %s\n" "md5_key " "$md5_key"
  [[ "$md5_cert" != "$md5_key"  ]] && echo "XXX => SSL key mismatched"
  #[[ "$rsa_md5_cert" != "$rsa_md5_key" && "$ec_md5_cert" != "$ec_md5_key" ]] && echo "XXX => SSL key mismatched"
}

# 使用curl获取网站的SSL证书，然后使用openssl查看证书信息，包括到期日期
function getssl(){
  [[ -z $1 ]] && echo "input url" && return 1

  url="$1"
  # 取得 fqdn
  fqdn=$(echo "$url" | sed 's/^http[s]*:\/\///'| sed 's/\/.*$//')

  #is_resolved=$(ping -c 1 -W 1 $hostname > /dev/null 2>&1)
  is_resolved=$(dig +short @8.8.8.8 A $fqdn)
  [[ -z "$is_resolved" ]] && echo "not resolved" && return 1


  # 检查是否带有 http:// 前缀，如果有则替换为 https://
  if [[ $url != "https://"* ]]; then
      url="https://$url"
  fi
  expiration_date=$(curl $url -vI --stderr - | grep "expire date" | cut -d":" -f 2-)
  
  if [ -z "$expiration_date" ]; then
    # 使用sed命令去除http://或https://,URL路径部分
    expiration_date=$(echo | openssl s_client -servername $url -connect $url:443 2>/dev/null | openssl x509 -noout -enddate | cut -d "=" -f 2)
    formatted_date="XXX证书已过期，到期日： "$(date -d "$expiration_date" "+%Y-%m-%d")
  else
    formatted_date="SSL证书正常，到期日： "$(date -d "$expiration_date" "+%Y-%m-%d")

  fi
  echo $formatted_date
}

# 检查网站
curl_chk() {
    # 入口
    if [[ -z "$1" ]]; then
        echo "Usage: $0 domain.com"
        return
    fi

    local DOMAIN=$1
    local URL="https://$DOMAIN"

    echo "===== Header (PC) ====="
    curl -s -I -A "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/115.0 Safari/537.36" "$URL"

    echo -e "\n===== Header (Mobile) ====="
    curl -s -I -A "Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 Mobile/15E148 Safari/604.1" "$URL"

    echo -e "\n===== HTTP Version Support ====="
    echo -n "HTTP/2: "
    curl -s -o /dev/null -w "%{http_version}\n" --http2 "$URL" || echo "Not Supported"
    echo -n "HTTP/3: "
    curl -s -I --http3 "$URL" > /dev/null 2>&1 && echo "Supported" || echo "Not Supported"

    echo -e "\n===== Speed Test ====="
    read -r TIME SPEED <<< $(curl -o /dev/null -s -w "%{time_total} %{speed_download}" "$URL")
    echo "Time: ${TIME}s"
    echo -n "Speed: "
    human_speed "$SPEED"

    echo -e "\n===== SSL Certificate ====="
    CERT_INFO=$(echo | openssl s_client -servername "$DOMAIN" -connect "$DOMAIN:443" 2>/dev/null | openssl x509 -noout -dates -subject)
    echo "$CERT_INFO" | grep 'subject='

    EXPIRE_DATE=$(echo "$CERT_INFO" | grep 'notAfter=' | cut -d= -f2)
    echo -e "\n证书到期日为：$EXPIRE_DATE"

    echo -e "\n===== DNS ====="
    dig +short "$DOMAIN"
}

