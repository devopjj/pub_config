# ~/.bashrc.d/00-env.sh

# 平台判断
OS_TYPE=$(uname)
case "$OS_TYPE" in
  Darwin)   export PLATFORM="macOS" ;;
  Linux)    export PLATFORM="Linux" ;;
  *)        export PLATFORM="Unknown" ;;
esac

NODE_TLS_REJECT_UNAUTHORIZED=0

if [ -z "${my_chroot:-}" ] && [ -r /etc/my_chroot ]; then
    my_chroot=$(cat /etc/my_chroot)
fi

HISTSIZE=1000
HISTFILESIZE=2000

DEFAULT_USER=$(whoami)

if [[ "$DEFAULT_USER" == "root" ]]; then
    export HOME=/root
else
    export HOME=/home/$(whoami)
fi

export PATH=/sbin:/usr/sbin:/bin:/usr/bin:/usr/local/bin:/usr/local/sbin:~/.local/bin

export ZHOST=$(hostname -s | tr -d '\n')

if [[ "$TERM" == "xterm" ]]; then
    export TERM=xterm-256color
fi
[[ $TMUX = "" ]] && export TERM="xterm-256color"

export PAGER="less -r"

export LN_ALL=en_US.UTF-8
export LANG=zh_TW.UTF-8
export LC_TIME=zh_TW.UTF-8

#-------------------------------------------------------------
# ---  Go Lang
#-------------------------------------------------------------
# Go 編譯器、Go 相關工具、標準函式庫所在的位置
export GOROOT=/usr/local/go
# 第三方應用程式和函式庫所在的位置
export GOPATH=/home/`whoami`/mygo
export PATH=$PATH:$GOROOT/bin:$GOPATH/bin