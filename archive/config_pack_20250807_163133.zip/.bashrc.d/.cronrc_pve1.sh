#!/bin/bash
#/*------------------------------------------------------------------------------------
# filename: .cronrc
# description: common file for mycron scripts
# update: 2025-05-15 16:32:57
# ------------------------------------------------------------------------------------*/
PROG=${0##*/}
#FNAME=${PROG%%.*}
FNAME=$(basename "$0" .sh 2>/dev/null)

# Common
GHOST=`hostname -s`
DATESN=`date '+%Y-%m-%d'`
ts=$(date '+%Y-%m-%d %H:%M:%S')
ts_min=$(date +%M)
ts_hour=$(date +%H)
SECONDS=0
start_time_msec=$(date +%s%3N)

# 获取当前脚本的路径
cronrc_path="$(dirname "$(realpath "${BASH_SOURCE[0]}" 2>/dev/null || echo "$0")")"
# 在 .cronrc 中获取调用它的脚本名称
#script_path="$(dirname "$(realpath "${BASH_SOURCE[1]}" 2>/dev/null || echo "$0")")"
grandparent_dir=$(dirname "$script_path" 2>/dev/null )

source "$cronrc_path/.nmsrc" 2>/dev/null
#if ! source "$cronrc_path/.nmsrc" 2>/dev/null; then
#  echo "错误: 无法 source $BASEDIR/.nmsrc，跳过错误继续执行"
#fi

# ----------------------------------
#  Variables
# ----------------------------------


# ----------------------------------
#  Logs
# ----------------------------------
# 程序日志

if [[ ! -z $SELF_LOGPATH && $SELF_LOGPATH == 1 ]];then
  abs_src_path=$(dirname $(realpath "$0"))
  log_path="${abs_src_path}/log"
else
  log_path="/share1/log"
fi

# 确保日志目录存在
[[ ! -d "$log_path" ]] && mkdir -p "$log_path"

# 排程日志（固定 /share1/log）
log_cron_path="/share1/log/cron-monitor"
[[ ! -d "$log_cron_path" ]] && mkdir $log_cron_path

# 定义日志文件
rawLog="$log_path/${GHOST}_${FNAME}.log"
touch ${rawLog} 2> /dev/null

# 任务结果日志
result="$log_path/${FNAME}.result"

# 定时任务日志基础路径
cron_log_basename="${log_cron_path}/${GHOST}_${FNAME}"
# 标准输出日志
outLog="${cron_log_basename}.out"
# 标准错误日志
errLog="${cron_log_basename}.err"
# 设置适当的文件权限，避免写入失败（根据需要调整权限）
sudo /bin/chmod 664 "$rawLog" "$outLog" "$errLog" 2>/dev/null

# Server
BAKSRV=10.11.11.21
BAKPATH=/backup/${GHOST}

#CRED="\e[91m"
#CGREEN="\e[92m"
#CYELLOW="\e[93m"
#CEND="\e[0m"

# ----------------------------------
#  COMMON END
# ----------------------------------
function check_exec_result() {
    # 定义状态码对应的数组
    local cmd="$1"      # 要执行的命令
    local result_prefix=${2:-"命令执行"} # 默认提示
    local success_msg="${result_prefix} 成功" # 成功时的默认提示
    local fail_msg="${result_prefix} 失败"    # 失败时的默认提示
    local exit_on_fail=${3:-1}     # 可选参数，是否在失败时退出（默认退出）

    #log "开始执行命令: $cmd"
    # 执行命令
    eval "$cmd" > $rawLog 2>&1 
    local status=$?  # 获取状态码

    if [ $status -eq 0 ]; then
        log  "$success_msg"
        return 0
    else
        log "error" "$fail_msg"
        if [ $exit_on_fail -ne 0 ]; then
            echo "失败后中断执行, log: $rawLog"
            tail -50  $rawLog
            exit $status
        fi
        return $status
    fi
}

# 清理函数
function cleanup() {
    echo "收到终止信号，正在退出..."
    # 终止所有子进程
    pkill -P $$
    exit 0
}

# 检查输入参数
function check_vars() {
    local idx=1
    local missing=false
    local script_name=$(basename "${BASH_SOURCE[0]}")

    for var in "$@"; do
        if [[ -z "$var" ]]; then
            log "error" "${script_name} 缺少第${idx}个变量"

            missing=true
        fi
        idx=$((idx + 1))
    done

    # 返回状态
    if $missing; then
        return 1
    fi

    return 0
}

# 通用函数：检查命令是否存在
function check_cmd_exist() {
    local cmd=$1
    local cmd_path=$(command -v "$cmd")

    if [[ -z "$cmd_path" ]]; then
        echo "CRITICAL: $cmd not found."
        exit 1
    fi
}

# 显示进度条
function show_progress() {
    [[ $(check_vars "$1" "$2") != "0" ]] && return 0
    local current=$1  # 当前进度
    local total=$2    # 总的进度值
    local percent=$((current * 100 / total))

    # 保存当前光标位置
    #tput sc
    # 移动光标到屏幕最底部
    #+#tput cup $(tput lines) 0

    # 打印进度条
    printf "\rProgress: %3d%% [%-50s]" "$percent" "$(printf '#%.0s' $(seq 1 $((percent / 2))))"
    
    # 恢复光标到原位置
    #+#tput rc

    # 如果完成所有任务
    if [ "$current" -eq "$total" ]; then
        echo -e "\nTask completed!\n"  # 换行并提示任务完成
    fi
}

# 使用正则表达式匹配数字，并检查是否大于 0
function is_positive_number() {
    local input="$1"
    if [[ "$input" =~ ^[0-9]+$ ]] && [ "$input" -gt 0 ]; then
        return 0  # 是正数，返回成功
    else
        return 1  # 不是正数，返回失败
    fi
}

# 定义一个函数，等待用户输入 "Y" 或 "y" 确认继续
function confirm_continue() {
    local prompt_message=${1:-"是否继续? 输入 Y 确认: "}
    while true; do
        # 确保提示信息正确显示
        echo -n "$prompt_message"
        read choice
        case "$choice" in
            Y|y) 
                return 0
                ;;
            *) 
                return 1
                ;;

        esac
    done
}


# 查找主进程PID
function find_main_pid() {
    local process_name="$1"
    # 使用 ps 搜索匹配的进程，排除 grep 本身
    local main_pid=$(ps -eo pid,ppid,cmd --sort=start_time | grep -E "[^/]*$process_name" | grep -v "grep" | awk '{print $1; exit}')
    
    if [ -z "$main_pid" ]; then
        echo "未找到主进程 $process_name"
        return 1
    fi

    echo "$main_pid"
    # 找到主进程的所有子进程
    #local child_pids=$(ps --ppid "$main_pid" -o pid --no-headers)
    #echo "$main_pid $child_pids"
}


# 将运行时间（如 0-07:26:19）转换为秒数
function format_time_to_seconds() {
    local elapsed_time=$1
    IFS='-' read -r days time_part <<< "$elapsed_time"
    IFS=':' read -r hours minutes seconds <<< "$time_part"

    # 确保去掉前导零并将其转换为数字
    days=${days#0}
    hours=${hours#0}
    minutes=${minutes#0}
    seconds=${seconds#0}

    # 计算总秒数
    echo $((days * 86400 + hours * 3600 + minutes * 60 + seconds))
}


function convert_seconds() {
    [[ -z $1 ]] && return
    # 函数：将秒转换为 日 时 分 秒
    local total_seconds=$1

    # 计算各时间单位
    local days=$((total_seconds / 86400))
    local hours=$(( (total_seconds % 86400) / 3600 ))
    local minutes=$(( (total_seconds % 3600) / 60 ))
    local seconds=$((total_seconds % 60))

    # 构建输出字符串
    local time_str=""
    [[ $days -gt 0 ]] && time_str+="${days}天 "
    [[ $hours -gt 0 ]] && time_str+="${hours}时 "
    [[ $minutes -gt 0 ]] && time_str+="${minutes}分 "
    [[ $seconds -gt 0 ]] && time_str+="${seconds}秒"
    # 输出结果，移除末尾空格
    echo "${time_str% }"
}

function countdown_timer() {
    # 检查参数个数和是否为正整数
    if [ $# -lt 1 ] || ! [[ $1 =~ ^[0-9]+$ ]]; then
        echo "用法: countdown_timer <正整数秒数> [标语]"
        return 1
    fi

    local countdown=$1  # 设置倒计时时间（秒）
    local slogan=${2:-"倒数"}  # 使用传入的标语或默认的 "倒数"
    local end_time=$(($(date +%s%3N) + countdown * 1000))  # 计算结束的时间戳（精确到毫秒）

    # 将结束时间戳转换为日期格式（精确到秒）
    local end_time_formatted=$(date -d "@$((end_time / 1000))" "+%Y-%m-%d %H:%M:%S")
    echo -e "\n预计结束时间: $end_time_formatted"

    # 倒计时循环
    while [ $(date +%s%3N) -lt $end_time ]; do
        local current_time=$((end_time - $(date +%s%3N)))
        local total_seconds=$((current_time / 1000))
        local fractional_seconds=$((current_time % 1000 / 10))  # 显示两位小数
        local hours=$((total_seconds / 3600))
        local minutes=$(((total_seconds % 3600) / 60))
        local seconds=$((total_seconds % 60))        

        # 格式化倒计时显示为 "秒.毫秒" 的格式
        #printf "%s: %02d.%02d 秒\r" "$slogan" "$seconds" "$fractional_seconds"
        # 格式化倒计时显示为 "小时:分钟:秒.毫秒" 的格式
        printf "%s: %02d:%02d:%02d.%02d\r" "$slogan" "$hours" "$minutes" "$seconds" "$fractional_seconds"

        sleep 0.01  # 每10毫秒更新一次倒计时显示
    done

    echo -e "\n倒计时结束！"
}

#function logStderr() {
#  local errLog="${log_cron_path}/${GHOST}_${FNAME}.err"
#  exec 2>>"$errLog"
#}

#function logStdout() {
#  local outLog="${log_cron_path}/${GHOST}_${FNAME}.out"
#  exec 1>>"$outLog"
#}

# 设置全局日志重定向
function setupLogRedirection() {
    # 确保错误日志文件存在，如果不存在则创建
    touch "$errLog"

    # 在脚本初始化时设置标准错误输出重定向，将错误日志写入文件并加上时间戳
    exec 2> >(sudo tee -a "$errLog" | sed "s/^/$(date '+%Y-%m-%d %H:%M:%S') /" >&2)
}

# 监控 Python 进程的 CPU 和内存使用情况
monitor_deadlock() {
    pid=$1
    timeout=60  # 设置超时时间，单位为秒
    elapsed=0
    while [ $elapsed -lt $timeout ]; do
        # 获取当前 Python 进程的 CPU 和内存使用情况
        cpu_usage=$(ps -p $pid -o %cpu --no-headers)
        mem_usage=$(ps -p $pid -o %mem --no-headers)
        
        # 如果 CPU 使用率为零且内存占用过低，可能发生死锁
        if [ "$(echo "$cpu_usage == 0" | bc)" -eq 1 ] && [ "$(echo "$mem_usage < 10" | bc)" -eq 1 ]; then
            echo "怀疑进程 $pid 发生死锁，CPU: $cpu_usage%, 内存: $mem_usage%" |sudo tee -a "$errLog"
            sendtg "怀疑进程 $pid 发生死锁，CPU: $cpu_usage%, 内存: $mem_usage%"   # 发送消息到 Telegram
            return 1
        fi
        
        sleep 5
        elapsed=$((elapsed + 5))
    done
    return 0
}

# 定义日志追加函数
function appendLog() {  
  local logTime=$(date '+%Y-%m-%d %H:%M:%S')
  
  # 在日志中添加启动日志记录的时间标记
  echo "appendLog >> $logTime" | sudo tee -a "$outLog" 2>&1 > /dev/null

  # 确保错误日志文件存在，如果不存在则创建
  #touch "$errLog"

  # 将标准错误输出重定向到日志文件并加上时间戳
  #exec 2> >(tee -a "$errLog" | timestamp >&2)  
  # 将标准错误输出重定向到日志文件并加上时间戳
  exec 2> >(sudo tee -a "$errLog" | sed "s/^/$(date '+%Y-%m-%d %H:%M:%S') /" >&2)  
}

# 定义 appendRawLog 函数，将输出附加到日志文件
function appendRawLog() {
    echo $outLog
    if [ ! -f "$outLog" ]; then
        echo "Error: Log file path is not valid or does not exist."
        exit 1
    fi    
    while IFS= read -r log_message; do  # 从标准输入读取日志信息
        echo "${DATESN}: $log_message" >> "$outLog"  # 将日志信息附加到日志文件
    done
}

# 磁盘使用率
function du_files() {
  [[ -z $1 ]] && echo "must input path" && return 1
  [[ -z $2 ]] && echo "must output log file" && return 1

  disk_path=$1
  outLog=$2

  # 执行 du 格式化输出
  usage=$(/bin/df -kh $1|grep backup|awk '{print $4" "$6" (本地磁碟使用率："$5")"}')
  echo  "${DATESN}: $usage" | tee -a $outLog
}


# 磁盘使用率
function df_path() {
  [[ -z $1 ]] && echo "must input path" && return 1
  [[ -z $2 ]] && echo "must input critical" && return 1
  [[ ! $2 =~ ^[0-9]+$ ]] && echo "critical must be a number" && return 1

  local disk_path=$1
  local critical=$2

  # 获取磁盘使用率
  #local usage=$(/bin/df -kh "$disk_path" | awk 'NR==2 {print $5}')
  #usage_percent=${usage%\%}
  local usage_percent=$(/bin/df --output=pcent "$disk_path" 2>/dev/null | tail -n 1 | tr -d ' %')

  # 判断是否超出 critical
  if [[ $usage_percent -ge $critical ]]; then
    echo 1
    return 1
  else
    echo 0
    return 0
  fi
}


function push_promgateway(){
    # 检查传入的参数是否为空
    if [[ -z "$1" || -z "$2" || -z "$3" || -z "$4" || -z "$5" ]]; then
        echo "参数错误：必须传入5个参数"
        return 1
    fi
    # 定义指标
    METRIC_NAME="$1"
    INSTANCE_NAME="$2"
    JOB_NAME="$3"
    #LABELS="job=\"$JOB_NAME\""
    EXECUTION_TIME="$4"
    RESULT="$5"
    # 设置标签
    LABELS="job=\"$JOB_NAME\", instance=\"$INSTANCE_NAME\", result=\"$RESULT\""

    # 推送指标到 Pushgateway，并最多重试 3 次
    RETRY_COUNT=0
    MAX_RETRIES=3
    while [[ $RETRY_COUNT -lt $MAX_RETRIES ]]; do
        echo "${METRIC_NAME}{${LABELS}} ${EXECUTION_TIME}" | curl --data-binary @- "${PUSHGATEWAY_URL}/metrics/job/${JOB_NAME}"
        # 输出推送成功的消息
        if [[ $? -eq 0 ]]; then
            echo "成功推送指标到 Pushgateway"
            return 0  # 成功后退出函数
        else
            RETRY_COUNT=$((RETRY_COUNT + 1))
            if [[ $RETRY_COUNT -lt $MAX_RETRIES ]]; then
                echo "推送失败，正在进行重试 ($RETRY_COUNT/$MAX_RETRIES)"
            fi
        fi
    done
    # 如果超过最大重试次数依然失败，输出失败消息
    echo "推送失败，已达到最大重试次数 ($MAX_RETRIES)"
    return 1   
}


# 脚本通用结尾
function appendEndofScript(){
  
  ELAPSED=" $(($SECONDS / 3600))hrs $((($SECONDS / 60) % 60))min $(($SECONDS % 60))sec"
  
  end_time_msec=$(date +%s%3N)
  elapsed_time_msec=$((end_time_msec - start_time_msec))

  # 排程执行+NOTIFY_TG：才发通知
  CRON_FLAG=$(echo "$CRON_FLAG" | tr '[:upper:]' '[:lower:]')
  NOTIFY_TG=$(echo "$NOTIFY_TG" | tr '[:upper:]' '[:lower:]')

  # 写入记录供监控
  [[ -z "$exec_result" ]] && exec_result=$?

  if [ "$exec_result" = "0" ] ;then
    echo "${ts} - ${FNAME} - Job completed" >> ${cron_log_basename}
    job_result="✅ 排程任务成功 ${GHOST}"
  else
    echo "${ts} - ${FNAME} - Job failed" >> ${cron_log_basename}
    job_result="❌ 排程任务失败 ${GHOST}"
  fi

  # push gateway
  #push_promgateway $FNAME $ELAPSED $exec_result
  echo $(date +"%Y-%m-%dT%H:%M:%SZ") $GHOST $(whoami) $FNAME $elapsed_time_msec $exec_result |sudo tee -a /share1/log/job_result/${FNAME}.log

  # 读取记录当日最后2行
  if [ "$CRON_FLAG" != "false" ] &&  [ "$NOTIFY_TG" == "true" ]; then
      local stdOut=$(cat ${outLog} | grep -E "^${DATESN}|${DATESN}.chk")

      # 附加 error信息: 从原始日志过滤 ERROR|Failed，以栏位3:档名为排序key
      #echo "CRON_FLAG=${CRON_FLAG},NOTIFY_TG=${NOTIFY_TG} .ERROR|Failed, errLog=${errLog}, rawLog=${rawLog}, outLog=${outLog}"
      if [ -f $rawLog ]; then
        local err_result=$(grep -E "ERROR|Failed" ${rawLog} | cut -d ":" -f1,3-5,11 | awk '!seen[$3]++'|sed -e "s/\"//g")
      elif [ -s $errLog ];then
      echo 222
        local err_result="❌"$(cat ${errLog})
      fi

      #local stdOut=$(cat ${log} |tail -2)
      sendtg "${job_result}： $FNAME，耗时：${ELAPSED}\n${stdOut}\n${err_result}"
  else
      echo "${job_result}： $FNAME，耗时：${ELAPSED}"
  fi

}

# 等待秒數
function wait_seconds(){
  min=$1
  max=$2
  if [ -z "$min" ] || [ -z "$max" ]; then
      echo "Usage: wait_seconds <min> <max>"
      return 1
  fi
  # 生成一个 5~20 的随机数
  random_sleep=$(( (RANDOM % ${max}) + ${min} ))
  echo "随机休眠时间为 ${random_sleep} 分钟"
  sleep ${random_sleep}m
  }


# 依日期清理（保留）数量
function keep_latest_files() {
    local path="$1"
    local keep_count="$2"

    if [ -z "$path" ] || [ -z "$keep_count" ]; then
        echo "Usage: keep_latest_files <path> <count>"
        sendtg "$GHOST keep_latest_files failed"
        return 1
    fi

    # 切换到指定路径
    cd "$path" || { echo "Failed to change directory to $path"; return 1; }

    if [ $(ls -1 | wc -l) -lt $keep_count ]; then
        echo "${DATESN}.chk clear files: ${path} no delete, $(ls -1 | wc -l) files is less then $keep_count"
        return 1
    fi

    # 获取最新的文件列表
    newest_files=($(ls -t | head -n "$keep_count"))

    # 输出将要保留的文件
    printf "Keeping the following files:\n"
    printf "%s\n" "${newest_files[@]}"

    # 列出目录中的文件，排除 newest_files 中的文件，然后删除其余的旧文件
    to_delete=$(ls | grep -v -F -x -f <(printf "%s\n" "${newest_files[@]}"))
    # 删除其余旧文件
    if [[ -n "$to_delete" ]]; then
        delete_count=$(echo "$to_delete" | wc -l)
        echo "Deleting the following files:"
        echo "$to_delete"
        # delete files
        echo "$to_delete" | xargs rm -rf
        echo "Deleted $delete_count files."
    else
        delete_count=0
        echo "No files to delete."
    fi
    capacity=$(du -sh "$path")
    printf "${DATESN}: ${capacity}, Delete ${delete_count} files, Keep ${keep_count} files"

}

# 建立aws codecommit repo
function createAwsRepo(){
  [[ -z $1 ]] && echo "must input repo name" && return 1

    REPO="$1"
    [[ -z $2 ]] && repoDescription="$2" || repoDescripion="用于描述 git repo"
    cd "/data/home/gitrepo/$REPO" || return 1

    awsRegion="ap-east-1"
    echo "now create $awsRegion git repo"
    gitUrl=$(aws codecommit create-repository --repository-name $REPO --region $awsRegion | grep cloneUrlSsh|cut -d "\"" -f4)
    git init
    git remote add origin $gitUrl
    git add .
    git commit --allow-empty -m "${DATESN} 初始化"
    git push --set-upstream origin master
    aws codecommit update-repository-description --region $awsRegion --repository-name $REPO --repository-description $repoDescripion 
}

# 迁移到 Aws CodeCommit
function movetoAwsRepo(){
  [[ -z $1 ]] && echo "must input repo name" && return 1

    REPO="$1"
    cd "/data/home/gitrepo/$REPO"

    awsRegion="ap-east-1"
    gitUrl=$(aws codecommit create-repository --repository-name $REPO --region $awsRegion | grep cloneUrlSsh|cut -d "\"" -f4)
    git remote set-url origin $gitUrl
    git add .
    git commit --allow-empty -m "${DATESN} 由 gitea 转到 Aws"
    git push --set-upstream origin master
    echo aws codecommit update-repository-description --region $awsRegion --repository-name $REPO --repository-description "Your repository description" 
}
# ----------------------------------
#  Send Telegram
# ----------------------------------
function sendtg(){
  # 如果有参数，直接用；否则尝试读取 stdin
  if [ -n "$1" ]; then
    tg_text="$1"
  else
    tg_text="$(cat | sed ':a;N;$!ba;s/\n/\\n/g')"
  fi

  # 如果内容仍为空就直接退出
  if [ -z "$tg_text" ]; then
    echo "[sendtg] 警告：消息内容为空，已跳过发送。" >&2
    return 1
  fi
  # A00.JJ_Info
  chat_a00_JJ_Info="-1002061622893"
  jj01bot_token="1124675180:AAHXnQ03W_2B_lIcR2FRe4DrUopyXaXShYE"
  telegram_url="https://api.telegram.org/bot$jj01bot_token/sendMessage"
  tg_text="$tg_text\n -- $GHOST"

  #log  "$tg_text"
  # 使用 jq 构建 JSON，自动处理所有转义问题
  json_payload=$(jq -n \
    --arg chat_id "$chat_a00_JJ_Info" \
    --arg text "$tg_text" \
    '{chat_id: $chat_id, text: $text, parse_mode: "Markdown", disable_notification: true}'
  )
  #curl -q -s -X POST \
  #-H 'Content-Type: application/json' \
  #-d "$json_payload" \
  #$telegram_url >/dev/null

  curl -q -s -X POST \
  -H 'Content-Type: application/json' \
  -d '{"chat_id": '"$chat_a00_JJ_Info"', "text": "'"$tg_text"'", "parse_mode": "Markdown", "disable_notification": true}' \
  $telegram_url >/dev/null
  #echo "send telegram successfully!"
} 

# ----------------------------------
#  启用 vevn
# ----------------------------------
function run_venv(){
    # 直接激活虚拟环境
    echo "正在激活虚拟环境..."
    
    source ./venv/bin/activate
    
    # 检查激活是否成功
    if [ $? -ne 0 ]; then
        echo "激活虚拟环境失败，请检查虚拟环境路径。"
        return 1
    fi
    
    echo "虚拟环境已激活：$VIRTUAL_ENV"
}


# 将结果返回给调用者
function return_result() {
    local status="$1"  # 成功或失败
    local message="$2"  # 返回的消息内容
    echo "RESULT: $status - $message"  # 输出给调用者，可根据需求调整
}

# ----------------------------------
# 定义xvfb_auto_run函数，
# 用于动态寻找可用的X server display
# ----------------------------------
xvfb_auto_run() {
    local cmd=()  # 初始化一个空数组
    trap 'echo "中断信号接收到，终止进程"; pkill -f "Xvfb :${server_num}"; exit 0' SIGINT

    for arg in "$@"; do
        if [[ "$arg" != "-f" ]]; then
            cmd+=("$arg")  # 只添加非 -f 参数
        fi
    done    

    # 查找可用的显示编号
    local server_num=1  # 从 :1 开始
    local max_server_num=10  # 设置一个最大检查值，避免无限循环

    while [ $server_num -lt $max_server_num ]; do
        if ! lsof -i :59${server_num} > /dev/null 2>&1; then
            break
        fi
        ((server_num++))
    done

    # 使用 --auto-servernum 自动分配 server-num，并运行传入的命令
    xvfb_cmd="xvfb-run -n ${server_num}  -s \"-screen 0 1024x768x16\" ${cmd[@]}"
    # 打印运行指令到控制台
    echo "运行指令为：$xvfb_cmd"

    # 清理
    pkill -f "Xvfb :${server_num}" > /dev/null 2>&1

    # 执行命令
    eval $xvfb_cmd
    local exit_code=$?
    # 检查执行是否成功
    if [ $exit_code -ne 0 ]; then
        echo "Error: Command failed with exit code $exit_code" >&2
        return $exit_code
    fi
    return 0
}

# ----------------------------------
#  ping health checks
# ----------------------------------
function ping_hc(){
    [[ ! -z "$1" ]] && arg="/$1"
    slug=$(generate_slug $GHOST $FNAME)
    ping_url="${hc_api_url}/ping/${hc_ping_key}/${slug}${arg}"
    
    curl -fsS -m 10 --retry 3 -o /dev/null "$ping_url"
    if [ "$?" == "0" ];then
    echo "healthchecks successfully"
    else
    echo "healthchecks failed"
    fi
}

# 生成 slug 的函数
function generate_slug() {
  [[ -z $1 ]] && echo "must input host" && return 1
  [[ -z $2 ]] && echo "must input command" && return 1
  local host="$1"
  local command="$2"

  # 直接将命令结果赋值给 cron_entry
  local cron_entry=$(grep -h "$command" ${lxc_crond_path}/${host}/* 2>/dev/null | grep -v "#")
  # 输出调试信息

  # 检查匹配的行数
  local line_count
  line_count=$(echo "$cron_entry" | wc -l)

  if [ "$line_count" -gt 1 ]; then
    echo "匹配的行数大于 1"
    return 1
  elif [ "$line_count" -eq 0 ]; then
    echo "没有找到匹配的行"
    return 1
  else

    # 提取命令部分（从第6个字段开始）
    local command_part

    # 从第6个字段开始提取，并将空格分隔成数组
    # 使用 awk 提取从第6个字段开始的内容
    command_part=$(echo "$cron_entry" | awk '{for(i=6;i<=NF;i++) printf $i" "; print ""}')

    # 如果命令部分为空，报错
    if [ -z "$command_part" ]; then
        echo "cron_entry 格式不正确。" >&2
        return 1
    fi

    # 去除特殊字符，只保留字母、数字、空格、斜杠(/)和短横线(-,)多余的空格
    local cleaned_entry=$(echo "$command_part" | sed 's/[^a-zA-Z0-9 /-]//g'|sed -e 's/\ //g')

    # 替换斜杠(/)为短横线(-)
    cleaned_entry=$(echo "$cleaned_entry" | sed 's/\//-/g')

    # 转为小写
    local slug=$(echo "$cleaned_entry" | tr '[:upper:]' '[:lower:]')

    # 返回生成的 slug
    echo "$slug"
  fi
}

# 锁文件检查函数，接受锁文件名作为参数
function ensure_single_instance() {
    local lockfile="/tmp/${GHOST}_${FNAME}.lock"
    if [ -n "$1" ];then
        lockfile="$1"
    fi
    # 如果锁文件存在，表示脚本正在运行
    log "INFO" "lockfile=$lockfile"  # 记录锁文件路径

    # 使用 flock 进行文件锁定，避免竞争状态 race condition
    # 打开文件描述符 200 并关联到锁文件
    exec 200>"$lockfile" || {
        log "ERROR" "文件锁开启失败: $lockfile"
        exit 1
    }

    if ! flock -n 200; then
        local holder_pid=$(cat "$lockfile" 2>/dev/null || echo "unknown")
        log "ERROR" "脚本已在运行中 (PID: $holder_pid). 退出."
        exit 1        
    fi

    # 记录当前 PID 到锁文件
    echo $$ > "$lockfile"

    # 定义清理函数
    function clean_lockfile() {
        rm -f "$lockfile" 2>&1 > /dev/null
        log "INFO" "脚本结束，删除锁文件。"
    }
    # 设置 trap 清理锁文件
    #trap "rm -f $lockfile; log INFO '脚本结束，删除锁文件。'" EXIT SIGINT SIGTERM
    # 捕捉 EXIT, SIGINT 和 SIGTERM 信号，执行清理
    trap clean_lockfile EXIT SIGINT SIGTERM    
}

# 日志级别控制
function log() {
    local level="INFO"  # 设置默认 level 为 INFO
    local message=""
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')  # 获取当前时间戳
    local log_format="[%s] [%s] %s"  # 日志格式

    
    if [[ $# -eq 1 ]]; then
        # 如果只传入一个参数，则视为 message
        message="$1"
    elif [[ $# -eq 2 ]]; then
        # 如果传入两个参数，则第一个是 level，第二个是 message
        level="${1^^}"
        message="$2"
    fi


    [[ -z $rawLog ]] && rawLog=$(pwd)/debug.log

    # 如果 level 为空，设置为默认值 INFO
    [[ -z $level ]] && level="INFO"

    # 确保 DEBUG 变量已定义
    : "${DEBUG:=false}"  # 如果 DEBUG 未定义，则默认为 false

    # 检查日志级别是否有效
    case "$level" in
        "INFO"|"WARN"|"WARNING"|"ERROR"|"DEBUG") ;;
        *) level="UNKNOWN" ;;
    esac

    # 根据日志级别输出日志
    if [[ "$level" == "DEBUG" && "$DEBUG" != "true" ]]; then
        return  # 如果 DEBUG 级别且 DEBUG 变量不为 true，则不输出
    fi

    # 输出日志到文件和控制台
    {
        printf "$log_format" "$timestamp" "$level" "$message" | sed -e "s/$/\\n/g" 
    } |sudo tee -a "$rawLog" 
    #>&2  # ➤ 输出到 stderr，避免污染 stdout
}

# 函数：检查是否超过指定小时数
function check_time_interval() {
    [[ -z $1 ]] && return 1
    # 定义时间戳文件路径
    TIMESTAMP_FILE="${cron_log_basename}.lastrun"
    local hours=$1                     # 获取传入的小时数
    local current_time=$(date +%s)    # 当前时间戳
    local interval=$((hours * 3600))  # 转换小时为秒

    # 如果时间戳文件不存在，则视为超过时间间隔
    if [ ! -f "$TIMESTAMP_FILE" ]; then
        echo "$current_time" > "$TIMESTAMP_FILE"  # 初始化时间戳
        return 0  # 返回真（首次执行）
    fi

    # 获取上次运行的时间戳
    local last_run_time=$(cat "$TIMESTAMP_FILE")
    local time_diff=$((current_time - last_run_time))

    # 判断是否超过指定时间间隔
    if [ "$time_diff" -ge "$interval" ]; then
        echo "$current_time" > "$TIMESTAMP_FILE"  # 更新时间戳
        return 0  # 返回真
    else
        return 1  # 返回假
    fi
}

# 封装文件检查函数
function check_file_modified() {
    local file_path="$1"
    local last_time="$2"
    local current_time
    current_time=$(stat -c %Y "$file_path" 2>/dev/null)

    if [ $? -ne 0 ]; then
        log "配置文件 $file_path 不存在，退出。"
        exit 1
    fi

    if [ "$current_time" -ne "$last_time" ]; then
        # 文件已更新
        echo "$current_time"  # 返回新的修改时间
        return 0 
    else
        # 文件未更新
        echo "$last_time"  # 返回旧的修改时间
        return 1
    fi
}

# 输出文件大小
function get_file_size() {
    local file="$1"
    if stat -c%s "$file" >/dev/null 2>&1; then
        stat -c%s "$file"  # Linux
    elif stat -f%z "$file" >/dev/null 2>&1; then
        stat -f%z "$file"  # macOS / BSD
    else
        echo 0  # 出错时返回0
    fi
}


# 抖音用 mysql
function dmysql(){
    mysql --defaults-extra-file=/data/home/gitrepo/getDouYin/scripts/.my.cnf -Bse "$1"
}

# MySQL 执行函数
function mysql_slave_exec() {
    mysql -u$MYSQL_SLAVE_USER -p$MYSQL_SLAVE_PASSWORD -h$MYSQL_SLAVE_HOST  -P$MYSQL_SLAVE_PORT -e "$1"
}

# 使用cgroup限制资源的函数
run_with_cgroup_limit() {
    local cpu_pct="${1:-30}"         # CPU 百分比
    local mem_mb="${2:-512}"         # 内存 MB
    shift 2
    local cmd=("$@")  # ⚠️ 不再用 "$3" 当 input_file，避免吃掉 ffmpeg 本体                       # 剩下的是实际执行命令

    local base_name=$(basename "${cmd[0]}" | sed 's/[^a-zA-Z0-9._-]/_/g')  # 应为 ffmpeg
    local timestamp=$(date +%s%N)
    local group_id="ffmpeg-${base_name}-${timestamp}"
    local cgroup_path="/sys/fs/cgroup/${group_id}"
    local cpu_period=100000
    local cpu_quota=$((cpu_period * cpu_pct / 100))
    local mem_limit=$((mem_mb * 1024 * 1024))
    local log_file="/tmp/cgroup_${group_id}.log"

    sudo mkdir -p "$cgroup_path" 2>/dev/null || {
        echo "无法创建cgroup，以普通模式运行"
        "${cmd[@]}"
        return $?
    }

    echo "$cpu_period $cpu_quota" | sudo tee "$cgroup_path/cpu.max" > /dev/null 2>&1 || true
    echo "$mem_limit" | sudo tee "$cgroup_path/memory.max" > /dev/null 2>&1 || true

    {
        echo "[$(date)] CGroup created: $group_id"
        echo "From: ${cmd[0]}"
        echo "CPU: ${cpu_pct}%, Mem: ${mem_mb}MB"
        echo "Path: $cgroup_path"
        echo -n "Command: "; printf '%q ' "${cmd[@]}"; echo
    } > "$log_file"

    local exit_code=0
    (
        "${cmd[@]}" &
        local pid=$!
        echo $pid | sudo tee "$cgroup_path/cgroup.procs" > /dev/null 2>&1 || true
        wait $pid
        exit_code=$?
    )

    sudo rmdir "$cgroup_path" 2>/dev/null || true

    return $exit_code
}

# systemd 创建并强制生效的 cgroup 限制方式，比手动写 cgroup 目录更健壮。
run_with_limits_by_systemd() {
    local cpu_pct="${1:-30}"         # CPU 限制百分比
    local mem_mb="${2:-512}"         # 内存限制 MB
    shift 2
    local cmd=("$@")                 # 命令本体

    local timestamp=$(date +%s)
    local log_file="/tmp/sysd_run_${timestamp}.log"

    # 构建 systemd-run 命令
    local systemd_cmd=(
        systemd-run --quiet --scope
        -p "MemoryMax=${mem_mb}M"
        -p "CPUQuota=${cpu_pct}%"
        "${cmd[@]}"
    )

    # 日志打印
    echo "[$(date '+%F %T')] 使用 systemd-run 启动命令:" | tee "$log_file"
    printf '  %q ' "${systemd_cmd[@]}" | tee -a "$log_file"
    echo "" | tee -a "$log_file"

    # 实际运行
    sudo "${systemd_cmd[@]}"
    return $?
}

function add_temp_file() {
    local file="$1"
    temp_files+=("$file")
}


# 清理函数
function cleanup() {
    echo -e "\n⚠️ 捕获中断信号，开始清理临时资源(档案或目录)："

    for f in "${temp_files[@]}"; do
        if [[ -f "$f" ]]; then
            echo "🧹 删除: $f"
            rm -rf "$f"
        fi
    done

    exit 1
}


