#!/bin/bash
# =========================================================
# host: common
# service: bash/zsh
# filename: # ~/.bashrc.d/01-color.sh
# filedesc: Common RC file
# update: 2025-01-09 , 11:58
# =========================================================

#-------------------------------------------------------------
# VARIABLES 適合在腳本內直接輸出或處理顏色
#-------------------------------------------------------------
#
# 字的属性
#正常: 0
#加粗: 1 (需搭配終端介面設置)
#暗色: 2
#底線: 4
#閃爍: 5 (需搭配終端介面設置)
#相反色: 7 (即前景色與背景色對換)
#隱藏文字: 8

# 前景色 \[\033[屬性，顏色m\]
# 背景色 \[\033[背景m\]

#0831 # Normal Colors
#0831 Black='\[\033[30m\]'        # Black
#0831 Red='\[\033[31m\]'          # Red
#0831 Green='\[\033[32m\]'        # Green
#0831 Yellow='\[\033[33m\]'       # Yellow
#0831 Blue='\[\033[34m\]'        # Blue
#0831 Purple='\[\033[35m\]'      # Purple
#0831 Cyan='\[\033[36m\]'        # Cyan
#0831 White='\[\033[37m\]'       # White
#0831 
#0831 # Bold
#0831 BBlack='\[\033[01;30m\]'      # Black
#0831 BRed='\[\033[01;31m\]'        # Red
#0831 BGreen='\[\033[01;32m\]'      # Green
#0831 BYellow='\[\033[01;33m\]'     # Yellow
#0831 BBlue='\[\033[01;34m\]'       # Blue
#0831 BPurple='\[\033[01;35m\]'     # Purple
#0831 BCyan='\[\033[01;36m\]'       # Cyan
#0831 BWhite='\[\033[01;37m\]'      # White
#0831 
#0831 # Background
#0831 On_Black='\[\033[40m\]'      # Black
#0831 On_Red='\[\033[41m\]'        # Red
#0831 On_Green='\[\033[42m\]'      # Green
#0831 On_Yellow='\[\033[43m\]'     # Yellow
#0831 On_Blue='\[\033[44m\]'       # Blue
#0831 On_Purple='\[\033[45m\]'     # Purple
#0831 On_Cyan='\[\033[46m\]'       # Cyan
#0831 On_White='\[\033[47m\]'      # White
#0831 
#0831 
#0831 NC='\[\033[0m\]'                # Color Reset
# Normal Colors
Black='\033[30m'        # Black
Red='\033[31m'          # Red
Green='\033[32m'        # Green
Yellow='\033[33m'       # Yellow
Blue='\033[34m'         # Blue
Purple='\033[35m'       # Purple
Cyan='\033[36m'         # Cyan
White='\033[37m'        # White

# Underline
UBlack="\[\033[4;30m\]"       # Black
URed="\[\033[4;31m\]"         # Red
UGreen="\[\033[4;32m\]"       # Green
UYellow="\[\033[4;33m\]"      # Yellow
UBlue="\[\033[4;34m\]"        # Blue
UPurple="\[\033[4;35m\]"      # Purple
UCyan="\[\033[4;36m\]"        # Cyan
UWhite="\[\033[4;37m\]"       # White

# Background
On_Black="\[\033[40m\]"       # Black
On_Red="\[\033[41m\]"         # Red
On_Green="\[\033[42m\]"       # Green
On_Yellow="\[\033[43m\]"      # Yellow
On_Blue="\[\033[44m\]"        # Blue
On_Purple="\[\033[45m\]"      # Purple
On_Cyan="\[\033[46m\]"        # Cyan
On_White="\[\033[47m\]"       # White

# High Intensty
IBlack="\[\033[0;90m\]"       # Black
IRed="\[\033[0;91m\]"         # Red
IGreen="\[\033[0;92m\]"       # Green
IYellow="\[\033[0;93m\]"      # Yellow
IBlue="\[\033[0;94m\]"        # Blue
IPurple="\[\033[0;95m\]"      # Purple
ICyan="\[\033[0;96m\]"        # Cyan
IWhite="\[\033[0;97m\]"       # White

# Bold High Intensty
BIBlack="\[\033[1;90m\]"      # Black
BIRed="\[\033[1;91m\]"        # Red
BIGreen="\[\033[1;92m\]"      # Green
BIYellow="\[\033[1;93m\]"     # Yellow
BIBlue="\[\033[1;94m\]"       # Blue
BIPurple="\[\033[1;95m\]"     # Purple
BICyan="\[\033[1;96m\]"       # Cyan
BIWhite="\[\033[1;97m\]"      # White

# High Intensty backgrounds
On_IBlack="\[\033[0;100m\]"   # Black
On_IRed="\[\033[0;101m\]"     # Red
On_IGreen="\[\033[0;102m\]"   # Green
On_IYellow="\[\033[0;103m\]"  # Yellow
On_IBlue="\[\033[0;104m\]"    # Blue
On_IPurple="\[\033[10;95m\]"  # Purple
On_ICyan="\[\033[0;106m\]"    # Cyan
On_IWhite="\[\033[0;107m\]"   # White

# No Color
NC='\033[0m'            # No Color

#-------------------------------------------------------------
# 定義顏色 專門為 Bash 提示符（PS1）定義的
#-------------------------------------------------------------
# 定義顏色
PS1_Purple="\[\033[0;35m\]"
PS1_Yellow="\[\033[0;33m\]"
PS1_Green="\[\033[0;92m\]"
PS1_On_Black="\[\033[40m\]"
PS1_BBlue="\[\033[01;34m\]"

Reset="\[\033[0m\]"

# 顏色背景
PS1_ROSE="\[\033[38;5;232m\]\[\033[48;5;198m\]"
PS1_CPS="\[\033[38;5;229m\]\[\033[48;5;88m\]"
PS1_OCEAN="\[\033[38;5;231m\]\[\033[48;5;32m\]"

# 用戶名顏色
PS1_JJ="\[\033[38;5;229m\]"

# 2019-01-05
#== 1、語言符號及其分類(LC_CTYPE)
#== 2、數字(LC_NUMERIC)
#== 3、比較和排序習慣(LC_COLLATE)
#== 4、時間顯示格式(LC_TIME)
#== 5、貨幣單位(LC_MONETARY)
#== 6、信息主要是提示信息,錯誤信息,狀態信息,標題,標籤,按鈕和菜單等(LC_MESSAGES)
#== 7、姓名書寫方式(LC_NAME)
#== 8、地址書寫方式(LC_ADDRESS)
#== 9、電話號碼書寫方式(LC_TELEPHONE)
#== 10、度量衡表達方式 (LC_MEASUREMENT)
#== 11、默認紙張尺寸大小(LC_PAPER)
#== 12、對locale自身包含信息的概述(LC_IDENTIFICATION)。

# ---------------------------------------------------------------------------------------
#  Enviroment: EXPORT
# ---------------------------------------------------------------------------------------

force_color_prompt=yes

if [ -n "$force_color_prompt" ]; then
    if [ -x /usr/bin/tput ] && tput setaf 1 >&/dev/null; then
        color_prompt=yes
    else
        color_prompt=
    fi
fi


# JJ Env
if  grep -iq "JJ HOSTS" /etc/hosts;then
  PSCOLOR=$PS1_JJ
# 01 ROSE
elif [[ "$ZHOST" == *"worker03"* ]];then
  PSCOLOR=$PS1_OCEAN
# 02 OCEAN
elif [[ "$ZHOST" == *"template-"* ]]; then
  PSCOLOR=$PS1_ROSE
# 03 CPS
elif [[ "$ZHOST" == *"opc-"* ]];then
  PSCOLOR=$PS1_CPS
# JJ Env
else
  PSCOLOR=$PS1_BBlue
fi


if [ "$color_prompt" = yes ]; then
    PS1='${my_chroot:+($my_chroot)}\[\033[01;32m\]\u@\h\[\033[00m\]:\[\033[01;34m\]\w\[\033[00m\]\$ '
else
    PS1='${my_chroot:+($my_chroot)}\u@\h:\w\$ '
fi


# 設置提示符
if [ "$DEFAULT_USER" = root ] && [ "$SHELL" != "/bin/zsh" ]; then
    PS1="${Reset}\t-${PS1_CPS}\h:${Reset}${PS1_Yellow}\w${Reset}\$ "
elif [ "$SHELL" != "/bin/zsh" ]; then
    # 設置提示符顏色
    PS1="${PS1_JJ}\u@${PSCOLOR}\h${PS1_Green}${PS1_On_Black}[\w]${Reset}\$ "

fi



