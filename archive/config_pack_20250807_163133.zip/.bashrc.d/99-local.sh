# ~/.bashrc.d/99-local.sh
# Put your extra commands here

# acme SSL Ca  utils
if [ -f /home/jim/.acme.sh/acme.sh.env ];then
    . "/home/jim/.acme.sh/acme.sh.env"
fi

# ---------------------------------------------------------
#  Kubernetes
# ---------------------------------------------------------
if [ `which kubectl 2>/dev/null` ];then
    source "$HOME/.kubeletrc"
fi

# ssh connect alias
if [ -f $HOME/.ssh-host-alias.rc ];then
    source "$HOME/.ssh-host-alias.rc"
fi

#-------------------------------------------------------------
# Terraform 自动补全
#-------------------------------------------------------------
complete -C /usr/bin/terraform terraform

#-------------------------------------------------------------
# autojump
#-------------------------------------------------------------
[ -f /usr/share/autojump/autojump.bash ] && . /usr/share/autojump/autojump.bash

#-------------------------------------------------------------
# gopass, auto-load
#-------------------------------------------------------------
[ -f $HOME/.cred-manager/auto-load.sh ] && . $HOME/.cred-manager/auto-load.sh

#-------------------------------------------------------------
# ---  PATH
#-------------------------------------------------------------
# Go 編譯器、Go 相關工具、標準函式庫所在的位置
export GOROOT=/usr/local/go
# 第三方應用程式和函式庫所在的位置
export GOPATH=/home/`whoami`/mygo
export PATH=$PATH:$HOME/env.j/ops-toolkit:$GOROOT/bin:$GOPATH/bin:/home/jim/.pulumi/bin

