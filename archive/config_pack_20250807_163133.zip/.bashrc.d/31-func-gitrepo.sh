COMMIT_MSG="$1"
if [ -z "$COMMIT_MSG" ]; then
COMMIT_MSG="$(whoami)@$(hostname -s),$(date "+%Y%m%d %H:%M")"
fi 
    # 创建AwsCodeCommit(ap-east1)
function createAwsRepo(){
  [[ -z $1 ]] && echo "must input repo name" && return 1

  REPO="$1"
  awsRegion="ap-east-1"
  git init
  gitUrl=$(aws codecommit create-repository --repository-name $REPO --repository-description $REPO --region $awsRegion | grep cloneUrlSsh|cut -d "\"" -f4)
  git remote add origin $gitUrl
  git add .
  git commit -m "init,${DATESN}"
  git push --set-upstream origin master
}

function createGhRepo(){
  # 检查 gh 是否存在
  if ! command -v gh &>/dev/null; then
    echo "Error: GitHub CLI (gh) 未安装或未在 PATH 中。"
    return 1
  fi

  # 检查是否提供 repo 名
  if [[ -z "$1" ]]; then
    echo "Error: 必须提供 repo 名称"
    return 1
  fi

  local REPO="$1"
  local DESC="${2:-自动建立的私有仓库，用于项目代码管理。}"

  # 创建仓库
  gh repo create "$REPO" \
    --private \
    --description "$DESC" \
    --disable-issues \
    --disable-wiki \
    --clone 
  }
# push 後的觸發動作
alias gitpush_old='git add --all . && git commit -m "`whoami`@`hostname -s`,`date "+%Y%m%d %H:%M"`" && git push'
function gitpush() {
  git add --all . 
  # 嘗試 commit；失敗也繼續
  git commit -m "${COMMIT_MSG}" 

  # 檢查是否有 commit 尚未 push（即分支是否 ahead of origin）
  #if git status | grep -q "Your branch is ahead of"; then
    git push "$@"
  #  repo_name=$(basename -s .git "$(git config --get remote.origin.url)")
  #  /home/jim/env.j/scripts/post_push_trigger.sh "$repo_name"
  #else
  #  echo "[gitpush] Nothing to push."
  #fi

}

function gitrepo() {
# 获取 origin URL
url=$(git remote get-url origin)

# 初始化输出变量
platform=""
account=""

if [[ "$url" == *"github.com"* ]]; then
    platform="GitHub"
    # HTTPS: https://github.com/username/repo.git
    # SSH  : git@github.com:username/repo.git
    account=$(echo "$url" | sed -E 's#.*github\.com[:/](.+?)/.*#\1#')

elif [[ "$url" == *"codecommit"* ]]; then
    platform="AWS CodeCommit"
    # 示例1: https://git-codecommit.us-east-1.amazonaws.com/v1/repos/my-repo
    # 示例2: ssh://git-codecommit@us-east-1.amazonaws.com/v1/repos/my-repo
    # 示例3: codecommit::us-east-1://my-repo

    # 提取 AWS 账号 ID：URL 中在 `.amazonaws.com/` 前的部分
    account=$(echo "$url" | sed -E 's#.*git-codecommit\.(.+)\.amazonaws\.com/.*#\1#')
fi

echo "Platform : $platform"
echo "Repo URL : $url"
echo "Account  : $account"
}
function gitpush2a() {
  # 根据当前目录路径自动设置用户信息
  current_path=$(pwd)
  
  case "$current_path" in
    */work/* | */company/* | */jimia9899/* | */work-*)
      git config user.name "Jimia"
      git config user.email "jimia9899@gmail.com"
      echo "[gitpush] 🏢 使用jimia9899: $(git config user.name)"
      ;;
    */personal/* | */private/* | */projects/personal/* | */my-*)
      git config user.name "devopjj"  
      git config user.email "devopjj@gmail.com"
      echo "[gitpush] 🏠 使用个人账户: $(git config user.name)"
      ;;
    *)
      # 默认使用个人账户，并提示用户
      git config user.name "devopjj"
      git config user.email "devopjj@gmail.com"
      echo "[gitpush] ⚠️  使用默认个人账户"
      ;;
  esac

  git add --all .
  git commit -m "${COMMIT_MSG}" >/dev/null 2>&1

  #if git status | grep -q "Your branch is ahead of"; then
    git push "$@"
  #  repo_name=$(basename -s .git "$(git config --get remote.origin.url)")
    #/home/jim/env.j/scripts/post_push_trigger.sh "$repo_name"
  #else
  #  echo "[gitpush] Nothing to push."
  #fi
}
